const express = require('express');
const sqlite3 = require('sqlite3').verbose(); //Nyomkövetési és hibakeresés támogatása (verbose())
const app = express();
const PORT  = 3000;

//Middleware
app.use(express.json());

//Az adatbázis (fájl) inicializálása
const db = new sqlite3.Database('test.db', (err) => {
    if(err){
        console.log(err.message);
    }
    else{
        console.log('Az adatbázis kapcsolat létrejött.')
    }
});

//Adatbázis séma létrehozása
db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    firstName  TEXT NOT NULL,
    lastName TEXT NOT NULL,
    city TEXT NOT NULL,
    address TXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT NOT NULL,
    gender TEXT NOT NULL
    )`)

//Szerver elindítása
app.listen(PORT, () => {
console.log(`A webszerver fut a http://localhost:${PORT} webcímen.`)
})
