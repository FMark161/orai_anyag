const express = require('express');
const mysql = require('mysql2/promise'); //Nyomkövetési és hibakeresés támogatása (verbose())
const cors = require('cors'); //Cross Origin Resource Sharing - CORS védelem kiiktatása
const app = express();
const PORT = 3000;

//Middleware
app.use(express.json());
app.use(cors());

//MySql lapcsolat
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'ormdb'
});


//Modellek létrehozása
async function createTables() {
    await db.query(`
        CREATE TABLE IF NOT EXISTS users(
        id INT AUTO_INCREMENT PRIMARY KEY,
        firstName VARCHAR(255) NOT NULL,
        lastName VARCHAR(255) NOT NULL,
        city VARCHAR(255) NOT NULL,
        address VARCHAR(255) NOT NULL,
        phone VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        gender VARCHAR(255) NOT NULL
        )
    `);

    //Product modell létrehozása
    await db.query(`
        CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        price INT NOT NULL
        )
    `);

    //Orders modell létrehozása - pivot tábla
    await db.query(`
        CREATE TABLE IF NOT EXISTS orders (
         id INT AUTO_INCREMENT PRIMARY KEY,
         userId INT NOT NULL,
         status VARCHAR(255) NOT NULL,
         FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        )
    `);

    //Pivot tábla létrehozása
    await db.query(`
        CREATE TABLE IF NOT EXISTS orderproducts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        orderId INT NOT NULL,
        productId INT NOT NULL,
        FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
        )
    `);

    console.log("Az adatbázis táblái létrehozva és ellenőrizve.")
};
createTables();

//POST végpont az adatok eltárolására a users táblában
app.post('/api/users', (req, res) => {
    const { firstName, lastName, city, address, phone, email, gender } = req.body;
    const sql = `INSERT INTO users (firstName, lastName, city, address, phone, email, gender) VALUES (?, ?, ?, ?, ?, ?, ?)`;
    db.query(sql, [firstName, lastName, city, address, phone, email, gender],
        //Callback függvény az esetleges adatbázis kapcsolódási hiba kezelésére, vaggy a sikeres adatbázis művelet eredményének a visszaadaására
        function (err) {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: 'Hiba történt az adatok rögzítése során!' })
            }
            else {
                return res.status(201).send({ message: 'Az adatok rögzítése sikeres volt.', id: this.lastID, firstName, lastName, city, address, phone, email, gender })
            }
        }
    )
})

//GET végpont az adatbázis lekérdezésére
app.get('/api/users', (req, res) => {
    db.query(`SELECT * FROM users`, [], (err, records) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Hiba történt az adatok kiolvasása során!' })
        }
        else {
            //Hibakereséshez az adatok kilogolása a konzolra
            console.log('Az adatbázisunk sorai:', records);
            return res.status(200).json(records);
        }


    })

})

//DELETE végpont az adatbázis egy sorának (id szerinti) törlésére
app.delete('/api/users/:id', (req, res) => {
    //Az id elérése au URL paraméteréből
    const { id } = req.params;

    //Az adatbázis sorának tölése
    db.query(`DELETE FROM users WHERE id = ?`, [id],
        //Callback függvény a hiba kezelésre vagy a sikeres művelet nyugtázására
        function (err) {
            if (err) {
                return res.status(500).send(err.message);
            }
            else {
                res.status(200).json({ message: 'Sikeres adattörlés!' });
            }
        }

    )
})

//PUT végpont a táblázat adatainak a módosítására
app.put('/api/users/:id', (req, res) => {
    const { id } = req.params; //id elérése au URL paraméter listájából
    const { firstName, lastName, city, address, phone, email, gender } = req.body; //Az adatok kinyerése a kliens üzenet törzséből 
    const url = 'UPDATE users SET firstName = ?, lastName = ?, city = ?, address = ?, phone = ?, email = ?, gender = ? WHERE id = ?';
    db.query(url, [firstName, lastName, city, address, phone, email, gender, id],
        function (err) {
            if (err) {
                return res.status(500).send(err.message);
            }
            else {
                return res.status(200).json({ message: 'A felhasználó frissítése megtörtént!', id, firstName, lastName, city, address, phone, email, gender })
            }
        }
    )
})

//Rendelések rögzítése
app.post('/api/orders', async (req, res) => {
    const connection = await db.getConnection();
    try {
        const { userId, status, productIds } = req.body;
//Az adatbázis művelet elindítása
        await connection.beginTransaction();

        //Rendelés létrehozása
        const [orderResult] = await connection.query(
            `INSERT INTO orders (userId, status) VALUES (?, ?)`,
            [userId, status]
        );
        //Termék hozzárendelése
        const orderId = orderResult.insertId;
        //Pivot tábla feltöltése
        if (productIds && productIds.length > 0) {

        //Ciklussal bejárjuk a productId tömböt és pivottáblát feltöltjük az orderId és productId értékeivel
            for (const pid of productIds) {
                await connection.query(
                    `INSERT INTO orderproducts (orderId, productId) VAlUES (?, ?)`,
                    [orderId, pid]
                );
            }
        }
        //Az adatok elküldése az adatbázis szervernek
        await connection.commit();
        res.status(201).json(({ message: 'Rendelés létrehozva.', orderId }));
    }

    catch (err) {
        //Az adatbázis rollbackelése (visszaállítása)
        await connection.rollback();
        res.status(500).json({ message: 'Hiba a termék létrehozása során.' });
    }
    finally{
        connection.release();
    }
})

//Rendelések lekérése (felhasználóhoz rendelt)

app.get("/api/users/:id/orders/products", async (req, res) => {
    try {
        const userId = req.params.id;

        //Felhasználó lekérése
        const [[user]] = await db.query(`SELECT * FROM users WHERE id = ?`, [userId]);

        //Ha a user nincs az adatbázisban (users tábla)
        if (!user) return res.status(404).json({ message: 'A felhasználó nem található!' });

        //Rendelés lekérése
        const [orders] = await db.query(`SELECT * FROM orders WHERE userId = ?`, [userId]);

        //A felhasználó összes rendeléséhez tartozó összes termék lekérdezése
        /*
            1. Ciklussal végigmegy az összes rendelésen.
            2. JOIN-al lekérdezi a hozzájuk tartozó termékeket
            3. Az order.product-ba beleteszi őket
            4. Elküdli a kliensnek a rendeléseket és a hozáájuk tartozó termékeket
        */
        for (let order of orders) {
            const sql = 'SELECT p.* FROM products p JOIN orderproducts op ON op.productId = p.id WHERE op.orderId = ?';
            const [products] = await db.query(sql, [order.id])
            order.products = products;
        }
        res.status(200).json({...user, orders});
    }
    catch (err) {
        res.status(500).json(({message: 'Hiba a lekérdetés során!'}));
    }
})

//Szerver elindítása
app.listen(PORT, () => {
    console.log(`A webszerver fut a http://localhost:${PORT} webcímen.`)
})
