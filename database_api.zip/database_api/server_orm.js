const express = require('express');
const cors = require('cors');
const { Sequelize, DataTypes } = require('sequelize');
const app = express();
const PORT = 3000;

app.use(express.json())
app.use(cors());

//MySQL adatbázis kapcsolat Sequelize ORM-el
const sequelize = new Sequelize('ormdb', 'root', '',{
    host: 'localhost',
    dialect: 'mysql',
    logging: false
});

//User modell definiálása
const User = sequelize.define('User', {
    firstName: { type: DataTypes.STRING, allowNull: false},
    lastName: { type: DataTypes.STRING, allowNull: false},
    city: { type: DataTypes.STRING, allowNull: false},
    address: { type: DataTypes.STRING, allowNull: false},
    phone: { type: DataTypes.STRING, allowNull: false},
    email: { type: DataTypes.STRING, allowNull: false},
    gender: { type: DataTypes.STRING, allowNull: false}
},
{
    timestamp: false,
    tableName: 'users'
});

//Adatbázis szikronizálása (tábla létrehozása)
sequelize.sync()
.then(() => console.log('Adatbáis kapcsolat létrejött és a táblák szinkronizálva vannak'))
.catch(err => console.error('Hiba az adatbázis kapcsolata során', err));

//POST - új felhasználó létrehozása
app.post('/api/users', async (req,res) => {
    try {
    const user = await User.create(req.body);
    res.status(201).json({ message: 'A felhasználó rögzítése sikeres volt', user })
    }
    catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Hiba történt a felhasználó rögzítése során!' });
    }
})

app.get('/api/users', async (req,res) => {
    try {
    const users = await User.findAll();
    res.status(200).json(users);
    }
    catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Hiba történt az adatok lekérése során!' });
    }
})


app.delete('/api/users/:id', async (req, res) => {
    try {
        const deleted = await User.destroy ({
            where: { id: req.params.id}
        });

        if (deleted) {
            res.status(200).json({message: 'Sikeres adattörlés'});
        }
        else {
            res.status(404).json({message: 'A felhasználó nem található'})
        }
    }

    catch (err) {
        console.error(err);
        res.status(500).json({ message: ' Hiba történt a törlés során!'});
        
    }
})

app.put('/api/users/:id', async (req, res) => {
    try {
        const updated = await User.update ({
            where: { id: req.params.id}
        });

        if (updated [0] === 1) {
            res.status(200).json({message: 'A felhasználó frissítése megtörtént.'});
        }
        else {
            res.status(404).json({message: 'A felhasználó nem található'})
        }
    }

    catch (err) {
        console.error(err);
        res.status(500).json({ message: ' Hiba történt a frissítése  során!'});
        
    }
})

app.listen(PORT, () => {
    console.log(`A webszerver fut a http://localhost:${PORT} webcímen.`)
})




