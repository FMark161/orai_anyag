const express = require('express');
const mysql = require('mysql2'); 
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'etteremdb'
});

db.connect((err) => {
    if (err) {
        console.error('MySQL kapcsolati hiba: ', err);
    }
    else {
        console.log('Sikeres MySQL adatbázis kapcsolat.');
    }
});

//POST
app.post('/api/orders', (req, res) => {
    const { order_date, amount } = req.body;

    const sql = 'INSERT INTO orders (order_date, amount) VALUES (?, ?)';

    db.query(sql, [order_date, amount], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Adatbázis hiba!' });
        }

        return res.status(201).json({
            message: 'Sikeres mentés',
            id: result.insertId,
            order_date,
            amount
        });
    });
});


//GET
app.get('/api/orders', (req, res) => {
    db.query(`SELECT * FROM orders`, [], (err, records) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Hiba történt az adatok kiolvasása során!' })
        }
        else {
            console.log('Az adatbázisunk sorai:', records);
            return res.status(200).json(records);
        }


    })

})

//PUT
app.put('/api/orders/:id', (req, res) => {
    const { id } = req.params; 
    const { order_date, amount } = req.body;

    const sql = 'UPDATE orders SET order_date = ?, amount = ? WHERE id = ?';

    db.query(sql, [order_date, amount, id], function (err, result) {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Frissítési hiba!' });
        }
        res.status(200).json({ message: 'Adat frissítve!', id, order_date, amount });
    });
});


//DELETE
app.delete('/api/orders/:id', (req, res) => {
    const { id } = req.params;

    db.query(`DELETE FROM orders WHERE id = ?`, [id],
        function (err) {
            if (err) {
                return res.status(500).send(err.message);
            }
            else {
                res.status(200).json({ message: 'Sikeres adattörlés!' });
            }
        }

    )
})

app.listen(PORT, () => {
    console.log(`A webszerver fut a http://localhost:${PORT} webcímen.`)
})