//SQL modellek létrehozása
const db = require('../config/database');

//Táblák létrehozása
async function initTables() {
    await db.query(`
        CREATE TABLE IF NOT EXISTS users(
        id INT AUTO_INCREMENT PRIMARY KEY,
        firstName VARCHAR(255) NOT NULL,
        lastName VARCHAR(255) NOT NULL,
        city VARCHAR(255) NOT NULL,
        address VARCHAR(255) NOT NULL,
        phone VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        gender VARCHAR(255) NOT NULL
        )
    `);

    //Product modell létrehozása
    await db.query(`
        CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        price INT NOT NULL
        )
    `);

    //Orders modell létrehozása - pivot tábla
    await db.query(`
        CREATE TABLE IF NOT EXISTS orders (
         id INT AUTO_INCREMENT PRIMARY KEY,
         userId INT NOT NULL,
         status VARCHAR(255) NOT NULL,
         FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        )
    `);

    //Pivot tábla létrehozása
    await db.query(`
        CREATE TABLE IF NOT EXISTS orderproducts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        orderId INT NOT NULL,
        productId INT NOT NULL,
        FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
        )
    `);

    console.log("Az adatbázis táblái létrehozva és ellenőrizve.");
}

module.exports = initTables;