//Szerver indítása és az adatbázis táblák elkészítése
const app = require('./app');
const initTables = require('./models/initTables');

const PORT = 3000;
initTables().then() => {
    app.listen(PORT, () =>
        console.log(`A szerver fut: http://localhost:${PORT} címen.`);
    )
}