const router = require('express').Router();
const ctrl = require('../controllers/user.controller');

//A user.controller.js függvényeinek az elérése

router.post('/', ctrl.createUser);
router.get('/', ctrl.getUser);
router.delete('/:id', ctrl.deleteUser);
router.put('/:id', ctrl.updateUser);

module.exports = router;