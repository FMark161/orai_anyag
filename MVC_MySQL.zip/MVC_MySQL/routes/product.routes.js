const router = require('express').Router();
const ctrl = require('../controllers/product.controller');

//A product.controller.js függvényeinek az elérése

router.post('/', ctrl.createProduct);

module.exports = router;