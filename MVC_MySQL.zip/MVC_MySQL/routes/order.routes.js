const router = require('express').Router();
const ctrl = require('../controllers/orders.controller');

//A order.controller.js függvényeinek az elérése

router.post('/', ctrl.createOrders);
router.get('/:id/products', ctrl.getUserProductWith);

module.exports = router;
