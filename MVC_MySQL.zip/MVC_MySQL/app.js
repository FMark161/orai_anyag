//Middleware és routes

const express = require('express');
const cors = require('cors');

const userRoutes = require('./routes/user.routes');
const productRouters = require('./routes/product.routes');
const orderRoutes = require('./routes/order.routes');

const app = express();


//Middleware
app.use(express());
app.use(cors());

app.use('/api/users', userRoutes);
app.use('/api/products', productRouters);
app.use('api/orders', orderRoutes);

module.exports = app;