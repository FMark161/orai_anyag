//MyAQL kapcsolat beállítása
const mysql = require('mysql2/promise');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'ormdb2'
});

//A modul exportálása (más fájlokban is használható legyen)
module.exports = db;