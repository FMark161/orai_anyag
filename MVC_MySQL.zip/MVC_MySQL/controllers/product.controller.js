//A termékadatkezelés végponti szolgáltatásai

const db = require('../config/database');

//Új termék felvitele

exports.createProduct = async (req, res) => {
    try{
        const {name, price} = (req.body);

        const [result] = await db.query(
            `INSERT INTO products (name, price) VALUES (?, ?)`,
            [name, price]
        );
        res.status(201).json({ message: 'Termék sikeresen létrehozva!', id: result.insertId});
    }
    catch(err){
        res.status(500).json({ message: 'Hiba történt a termék létrehozása során!'});
    }
};