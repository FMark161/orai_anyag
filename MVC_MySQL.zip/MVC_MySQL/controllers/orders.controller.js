//A rendelések végponti szolgáltatásai

const db = require('../config/database');

exports.createOrders =  async (req, res) => {
    const connection = await db.getConnection();
    try {
        const { userId, status, productIds } = req.body;
//Az adatbázis művelet elindítása
        await connection.beginTransaction();

        //Rendelés létrehozása
        const [orderResult] = await connection.query(
            `INSERT INTO orders (userId, status) VALUES (?, ?)`,
            [userId, status]
        );
        //Termék hozzárendelése
        const orderId = orderResult.insertId;
        //Pivot tábla feltöltése
        if (productIds && productIds.length > 0) {

        //Ciklussal bejárjuk a productId tömböt és pivottáblát feltöltjük az orderId és productId értékeivel
            for (const pid of productIds) {
                await connection.query(
                    `INSERT INTO orderproducts (orderId, productId) VAlUES (?, ?)`,
                    [orderId, pid]
                );
            }
        }
        //Az adatok elküldése az adatbázis szervernek
        await connection.commit();
        res.status(201).json(({ message: 'Rendelés létrehozva.', orderId }));
    }

    catch (err) {
        //Az adatbázis rollbackelése (visszaállítása)
        await connection.rollback();
        res.status(500).json({ message: 'Hiba a termék létrehozása során.' });
    }
    finally{
        connection.release();
    }
};

exports.getUserProductWith =  async (req, res) => {
    try {
        const userId = req.params.id;

        //Felhasználó lekérése
        const [[user]] = await db.query(`SELECT * FROM users WHERE id = ?`, [userId]);

        //Ha a user nincs az adatbázisban (users tábla)
        if (!user) return res.status(404).json({ message: 'A felhasználó nem található!' });

        //Rendelés lekérése
        const [orders] = await db.query(`SELECT * FROM orders WHERE userId = ?`, [userId]);

        //A felhasználó összes rendeléséhez tartozó összes termék lekérdezése
        /*
            1. Ciklussal végigmegy az összes rendelésen.
            2. JOIN-al lekérdezi a hozzájuk tartozó termékeket
            3. Az order.product-ba beleteszi őket
            4. Elküdli a kliensnek a rendeléseket és a hozáájuk tartozó termékeket
        */
        for (let order of orders) {
            const sql = 'SELECT p.* FROM products p JOIN orderproducts op ON op.productId = p.id WHERE op.orderId = ?';
            const [products] = await db.query(sql, [order.id])
            order.products = products;
        }
        res.status(200).json({...user, orders});
    }
    catch (err) {
        res.status(500).json(({message: 'Hiba a lekérdetés során!'}));
    }
};
